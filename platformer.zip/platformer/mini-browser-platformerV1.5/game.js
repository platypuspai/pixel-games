const WIDTH = 200;
const HEIGHT = 150;
const GROUND_HEIGHT = 110;
const GRAVITY = 0.7;

const canvas = document.getElementById("game");
const ctx = canvas.getContext("2d");

// ── LEVELS ──────────────────────────────────────────────────────────────────
// Om een level toe te voegen: voeg gewoon een object toe aan deze array.
// Formaat: { name, player_start:[x,y], star:[x,y], obstacles:[[x,y,w,h], ...] }
const LEVELS = [
  {name:"Basis Parcours",player_start:[30,GROUND_HEIGHT-14],star:[165,GROUND_HEIGHT-70],
   obstacles:[[40,GROUND_HEIGHT-14,18,14],[80,GROUND_HEIGHT-32,18,14],[120,GROUND_HEIGHT-46,18,14]]},
  {name:"Trappenhuis",player_start:[10,GROUND_HEIGHT-14],star:[155,GROUND_HEIGHT-70],
   obstacles:[[30,GROUND_HEIGHT-14,20,14],[60,GROUND_HEIGHT-28,20,14],[90,GROUND_HEIGHT-42,20,14]]},
  {name:"Zigzag Sprint",player_start:[10,GROUND_HEIGHT-14],star:[180,GROUND_HEIGHT-28],
   obstacles:[[40,GROUND_HEIGHT-14,15,14],[80,GROUND_HEIGHT-60,15,40],[120,GROUND_HEIGHT-14,15,14]]},
  {name:"Dubbel Platform",player_start:[40,GROUND_HEIGHT-90],star:[180,GROUND_HEIGHT-100],
   obstacles:[[40,GROUND_HEIGHT-60,15,40],[120,GROUND_HEIGHT-60,15,40],[40,GROUND_HEIGHT-70,35,10],
              [120,GROUND_HEIGHT-70,35,10],[10,GROUND_HEIGHT-30,10,10],[30,GROUND_HEIGHT-50,10,10]]},
  {name:"Brug Run",player_start:[45,GROUND_HEIGHT-75],star:[180,GROUND_HEIGHT-80],
   obstacles:[[50,GROUND_HEIGHT-50,12,35],[150,GROUND_HEIGHT-50,12,35],[40,50,35,12],
              [135,50,35,12],[80,65,40,10],[10,GROUND_HEIGHT-30,10,10],[30,GROUND_HEIGHT-50,10,10]]},
  {name:"Precision Hop",player_start:[10,GROUND_HEIGHT-50],star:[185,GROUND_HEIGHT-70],
   obstacles:[[30,GROUND_HEIGHT-14,8,14],[50,GROUND_HEIGHT-28,8,14],[70,GROUND_HEIGHT-42,8,14],
              [90,GROUND_HEIGHT-42,8,14],[110,GROUND_HEIGHT-42,8,14],[130,GROUND_HEIGHT-42,8,14],
              [150,GROUND_HEIGHT-42,8,14],[170,GROUND_HEIGHT-42,8,14]]},
  {name:"De Uitdaging",player_start:[10,GROUND_HEIGHT-14],star:[180,GROUND_HEIGHT-70],
   obstacles:[[50,GROUND_HEIGHT-30,40,10],[130,GROUND_HEIGHT-40,40,10]]},
  {name:"Spikes & Gaps",player_start:[10,GROUND_HEIGHT-14],star:[185,GROUND_HEIGHT-56],
   obstacles:[[40,GROUND_HEIGHT-14,15,14],[90,GROUND_HEIGHT-42,15,14],[120,GROUND_HEIGHT-56,15,14]]},
  {name:"Sky Tower",player_start:[15,GROUND_HEIGHT-14],star:[175,45],
   obstacles:[[35,GROUND_HEIGHT-20,12,10],[70,GROUND_HEIGHT-35,12,10],[105,GROUND_HEIGHT-50,12,10],
              [140,GROUND_HEIGHT-65,12,10]]},
  {name:"Long Jump",player_start:[10,GROUND_HEIGHT-14],star:[180,GROUND_HEIGHT-60],
   obstacles:[[45,GROUND_HEIGHT-25,15,15],[100,GROUND_HEIGHT-45,50,10],[100,GROUND_HEIGHT-110,15,50]]},
  {name:"Slalom",player_start:[10,GROUND_HEIGHT-14],star:[155,GROUND_HEIGHT-70],
   obstacles:[
     [35,GROUND_HEIGHT-19,8,19],[35,0,8,GROUND_HEIGHT-38],
     [75,GROUND_HEIGHT-40,8,21],[75,0,8,GROUND_HEIGHT-59],
     [115,GROUND_HEIGHT-19,8,19],[115,0,8,GROUND_HEIGHT-38],
   ]},
  {name:"Piramide",player_start:[10,GROUND_HEIGHT-14],star:[95,GROUND_HEIGHT-100],
   obstacles:[
     [15,GROUND_HEIGHT-18,170,8],
     [30,GROUND_HEIGHT-32,140,8],
     [45,GROUND_HEIGHT-46,110,8],
     [60,GROUND_HEIGHT-60,80,8],
     [75,GROUND_HEIGHT-74,50,8],
     [88,GROUND_HEIGHT-88,24,8]
   ]},
     {name:"house",player_start:[10,GROUND_HEIGHT-14],star:[61,GROUND_HEIGHT-60],
   obstacles:[[180,GROUND_HEIGHT-70,10,70],[50,GROUND_HEIGHT-40,90,10],[140,GROUND_HEIGHT-10,10,10],[150,GROUND_HEIGHT-20,10,10],[160,GROUND_HEIGHT-30,10,10],[170,GROUND_HEIGHT-40,10,10],[30,GROUND_HEIGHT-80,170,10],[40,GROUND_HEIGHT-90,150,10],[50,GROUND_HEIGHT-100,130,10],[60,GROUND_HEIGHT-110,110,10],[40,GROUND_HEIGHT-70,10,50]]},
     {name:"heart",player_start:[10,GROUND_HEIGHT-84],star:[90,GROUND_HEIGHT-70],
   obstacles:[[90,GROUND_HEIGHT-10,10,10],[100,GROUND_HEIGHT-20,10,10],[90,GROUND_HEIGHT-20,10,10],[80,GROUND_HEIGHT-20,10,10],[70,GROUND_HEIGHT-30,10,10],[80,GROUND_HEIGHT-30,10,10],[90,GROUND_HEIGHT-30,10,10],[100,GROUND_HEIGHT-30,10,10],[110,GROUND_HEIGHT-30,10,10],[60,GROUND_HEIGHT-40,10,10],[70,GROUND_HEIGHT-40,10,10],[80,GROUND_HEIGHT-40,10,10],[90,GROUND_HEIGHT-40,10,10],[100,GROUND_HEIGHT-40,10,10],[110,GROUND_HEIGHT-40,10,10],[120,GROUND_HEIGHT-40,10,10],[60,GROUND_HEIGHT-50,10,10],[120,GROUND_HEIGHT-50,10,10],[70,GROUND_HEIGHT-50,10,10],[110,GROUND_HEIGHT-50,10,10],[60,GROUND_HEIGHT-60,10,10],[80,GROUND_HEIGHT-50,10,10],[100,GROUND_HEIGHT-50,10,10],[120,GROUND_HEIGHT-60,10,10],[70,GROUND_HEIGHT-60,10,10],[110,GROUND_HEIGHT-60,10,10],[50,GROUND_HEIGHT-50,10,10],[50,GROUND_HEIGHT-60,10,10],[50,GROUND_HEIGHT-70,10,10],[60,GROUND_HEIGHT-70,10,10],[70,GROUND_HEIGHT-70,10,10],[80,GROUND_HEIGHT-60,10,10],[90,GROUND_HEIGHT-50,10,10],[100,GROUND_HEIGHT-60,10,10],[110,GROUND_HEIGHT-70,10,10],[120,GROUND_HEIGHT-70,10,10],[130,GROUND_HEIGHT-70,10,10],[130,GROUND_HEIGHT-60,10,10],[130,GROUND_HEIGHT-50,10,10],[0,GROUND_HEIGHT-70,30,10],[10,GROUND_HEIGHT-60,10,60],[170,GROUND_HEIGHT-70,30,10],[180,GROUND_HEIGHT-60,10,60],[30,GROUND_HEIGHT-70,20,10],[140,GROUND_HEIGHT-70,30,10]]},
    {name:"3pats",player_start:[5,GROUND_HEIGHT-14],star:[190,GROUND_HEIGHT-20],
   obstacles:[[40,GROUND_HEIGHT-30,120,10],[20,GROUND_HEIGHT-20,10,10],[50,GROUND_HEIGHT-50,10,10],[70,GROUND_HEIGHT-60,100,10],[160,GROUND_HEIGHT-30,10,10],[70,GROUND_HEIGHT-4,10,4],[110,GROUND_HEIGHT-20,10,4],[80,GROUND_HEIGHT-33,10,4],[100,GROUND_HEIGHT-50,10,4],[120,GROUND_HEIGHT-33,10,4],[140,GROUND_HEIGHT-50,10,4],[160,GROUND_HEIGHT-33,10,4],[90,GROUND_HEIGHT-70,10,10],[90,GROUND_HEIGHT-110,10,24],[120,GROUND_HEIGHT-80,10,20],[120,GROUND_HEIGHT-110,10,15],[150,GROUND_HEIGHT-3,10,4]]},
    {name:"bomen",player_start:[10,GROUND_HEIGHT-14],star:[20,GROUND_HEIGHT-90],
   obstacles:[[40,GROUND_HEIGHT-10,10,10],[30,GROUND_HEIGHT-20,30,10],[40,GROUND_HEIGHT-30,10,10],[90,GROUND_HEIGHT-20,10,20],[80,GROUND_HEIGHT-30,30,10],[90,GROUND_HEIGHT-40,10,10],[140,GROUND_HEIGHT-10,10,10],[130,GROUND_HEIGHT-20,30,10],[140,GROUND_HEIGHT-30,10,10],[170,GROUND_HEIGHT-40,30,10],[180,GROUND_HEIGHT-50,10,10],[180,GROUND_HEIGHT-30,10,30],[130,GROUND_HEIGHT-60,30,10],[80,GROUND_HEIGHT-70,20,10],[70,GROUND_HEIGHT-70,10,10],[10,GROUND_HEIGHT-80,30,10]]},
  {name:"Robinhood",player_start:[10,GROUND_HEIGHT-100],star:[190,GROUND_HEIGHT-100],
   obstacles:[[20,GROUND_HEIGHT-30,10,30],[0,GROUND_HEIGHT-18,10,18],[50,GROUND_HEIGHT-60,10,20],[60,GROUND_HEIGHT-88,10,48],[80,GROUND_HEIGHT-110,40,49],[140,GROUND_HEIGHT-70,10,30],[150,GROUND_HEIGHT-94,10,44],[170,GROUND_HEIGHT-110,10,70],[170,GROUND_HEIGHT-40,10,10],[70,GROUND_HEIGHT-44,60,4],[160,GROUND_HEIGHT-30,20,10],[80,GROUND_HEIGHT-24,80,4],[50,GROUND_HEIGHT-40,10,40],[40,GROUND_HEIGHT-40,10,10],[180,GROUND_HEIGHT-34,10,4],[190,GROUND_HEIGHT-13,10,4],[190,GROUND_HEIGHT-55,10,4],[180,GROUND_HEIGHT-75,10,4],[20,GROUND_HEIGHT-40,10,10],[30,GROUND_HEIGHT-10,10,10],[40,GROUND_HEIGHT-50,10,10],[20,GROUND_HEIGHT-110,10,50],[30,GROUND_HEIGHT-81,10,11],[50,GROUND_HEIGHT-92,20,4],[140,GROUND_HEIGHT-94,10,4],[120,GROUND_HEIGHT-90,10,10],[130,GROUND_HEIGHT-50,10,10]]},   
   {name:"Arthur2",player_start:[10,GROUND_HEIGHT-14],star:[190,GROUND_HEIGHT-110],
   obstacles:[[0,GROUND_HEIGHT-22,190,4],[10,GROUND_HEIGHT-41,189,4],[0,GROUND_HEIGHT-62,190,4],[10,GROUND_HEIGHT-84,190,4],[180,GROUND_HEIGHT-94,20,10],[0,GROUND_HEIGHT-110,170,10]]},
  {name:"Arthur3",player_start:[10,GROUND_HEIGHT-14],star:[0,GROUND_HEIGHT-110],
   obstacles:[[30,GROUND_HEIGHT-20,10,20],[65,GROUND_HEIGHT-20,10,20],[100,GROUND_HEIGHT-20,11,20],[130,GROUND_HEIGHT-30,10,10],[105,GROUND_HEIGHT-85,10,10],[45,GROUND_HEIGHT-65,15,8],[15,GROUND_HEIGHT-75,15,10],[0,GROUND_HEIGHT-90,10,10],[124,GROUND_HEIGHT-60,12,10],[75,GROUND_HEIGHT-65,17,8]]},







   
 {name:"Nieuw Level",player_start:[10,GROUND_HEIGHT-14],star:[90,GROUND_HEIGHT-100],
   obstacles:[[20,GROUND_HEIGHT-40,10,10],[30,GROUND_HEIGHT-30,10,10],[40,GROUND_HEIGHT-20,10,20],[50,GROUND_HEIGHT-30,10,10],[60,GROUND_HEIGHT-40,10,10],[0,GROUND_HEIGHT-24,10,24],[80,GROUND_HEIGHT-40,10,40],[110,GROUND_HEIGHT-40,10,40],[90,GROUND_HEIGHT-40,20,10],[90,GROUND_HEIGHT-10,20,10],[130,GROUND_HEIGHT-40,10,40],[160,GROUND_HEIGHT-40,10,40],[140,GROUND_HEIGHT-10,20,10],[90,GROUND_HEIGHT-80,10,30],[120,GROUND_HEIGHT-80,10,30],[160,GROUND_HEIGHT-80,10,30],[130,GROUND_HEIGHT-80,10,10],[140,GROUND_HEIGHT-70,10,10],[150,GROUND_HEIGHT-60,10,10],[0,GROUND_HEIGHT-59,10,9],[60,GROUND_HEIGHT-80,10,20],[50,GROUND_HEIGHT-60,10,10],[40,GROUND_HEIGHT-70,10,10],[30,GROUND_HEIGHT-60,10,10],[20,GROUND_HEIGHT-80,10,20],[75,GROUND_HEIGHT-69,9,9],[180,GROUND_HEIGHT-10,10,10],[190,GROUND_HEIGHT-30,10,10],[180,GROUND_HEIGHT-60,10,10],[105,GROUND_HEIGHT-69,9,9]]},
]
// ── TIMER ────────────────────────────────────────────────────────────────────
let timerRunning = false;
let timerStart = 0;
let timerCurrent = 0;
let highscore = localStorage.getItem("platformer_highscore") ? parseInt(localStorage.getItem("platformer_highscore")) : null;

function timerString(ms) {
  const s = Math.floor(ms / 1000);
  const m = Math.floor(s / 60);
  const sec = s % 60;
  const tenth = Math.floor((ms % 1000) / 100);
  return `${m}:${sec.toString().padStart(2,"0")}.${tenth}`;
}

// ── DINO ─────────────────────────────────────────────────────────────────────
class Dino {
  constructor(x, y) { this.x=x; this.y=y; this.w=10; this.h=14; this.vx=0; this.vy=0; }
  collides(o) { return(this.x<o.x+o.w&&this.x+this.w>o.x&&this.y<o.y+o.h&&this.y+this.h>o.y); }
  canJump(obs) {
    if(this.y>=GROUND_HEIGHT-this.h) return true;
    for(let o of obs) {
      if(this.x+this.w>o.x&&this.x<o.x+o.w&&Math.abs(this.y+this.h-o.y)<2) return true;
    }
    return false;
  }
  update(obs) {
    this.x+=this.vx;
    for(let o of obs) {
      if(this.collides(o)) {
        if(this.vx>0) this.x=o.x-this.w;
        if(this.vx<0) this.x=o.x+o.w;
      }
    }
    this.vy+=GRAVITY;
    this.y+=this.vy;
    for(let o of obs) {
      if(this.collides(o)) {
        if(this.vy>0){this.y=o.y-this.h;this.vy=0;}
        if(this.vy<0){this.y=o.y+o.h;this.vy=0;}
      }
    }
    this.x=Math.max(0,Math.min(WIDTH-this.w,this.x));
    if(this.y>=GROUND_HEIGHT-this.h){this.y=GROUND_HEIGHT-this.h;this.vy=0;}
  }
  draw() { ctx.fillStyle="red"; ctx.fillRect(this.x,this.y,this.w,this.h); }
}

let currentLevel=0, obstacles=[], star, dino, keys={};

// ── MULTIPLAYER ───────────────────────────────────────────────────────────────
let peer = null;
let connections = [];
let remotePlayers = {};
let myPeerId = null;
const TIMEOUT_MS = 10000;

const statusEl = document.getElementById("mp-status");
const codeInput = document.getElementById("code-input");
const btnHost = document.getElementById("btn-host");
const btnJoin = document.getElementById("btn-join");
const btnJoinConfirm = document.getElementById("btn-join-confirm");

function setStatus(msg, color="#aaa") {
  statusEl.textContent = msg;
  statusEl.style.color = color;
}

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for(let i=0;i<4;i++) code += chars[Math.floor(Math.random()*chars.length)];
  return code;
}

// Stuur alleen als positie veranderd is of elke 30 frames (heartbeat)
let lastSentX = -1, lastSentY = -1, heartbeatCounter = 0;
function broadcastPosition() {
  if(!connections.length) return;
  heartbeatCounter++;
  const moved = Math.round(dino.x) !== lastSentX || Math.round(dino.y) !== lastSentY;
  if(!moved && heartbeatCounter < 30) return;
  heartbeatCounter = 0;
  lastSentX = Math.round(dino.x);
  lastSentY = Math.round(dino.y);
  const data = { type:"pos", x: lastSentX, y: lastSentY, level: currentLevel };
  for(let conn of connections) { if(conn.open) conn.send(data); }
}

function handleData(peerId, data) {
  if(data.type === "pos") {
    remotePlayers[peerId] = { x: data.x, y: data.y, level: data.level, lastSeen: Date.now() };
  }
}

function cleanupRemotePlayers() {
  const now = Date.now();
  for(let id in remotePlayers) {
    if(now - remotePlayers[id].lastSeen > TIMEOUT_MS) delete remotePlayers[id];
  }
}

function setupConn(conn) {
  connections.push(conn);
  conn.on("data", (data) => handleData(conn.peer, data));
  conn.on("close", () => {
    connections = connections.filter(c => c !== conn);
    delete remotePlayers[conn.peer];
    setStatus(connections.length ? `${connections.length} verbonden` : "offline", connections.length ? "#6f6" : "#aaa");
  });
  conn.on("error", () => {
    connections = connections.filter(c => c !== conn);
    delete remotePlayers[conn.peer];
    setStatus(connections.length ? `${connections.length} verbonden` : "offline", connections.length ? "#6f6" : "#aaa");
  });
  conn.on("open", () => setStatus(`${connections.length} verbonden`, "#6f6"));
}

btnHost.addEventListener("click", () => {
  if(peer) { peer.destroy(); peer=null; connections=[]; remotePlayers={}; }
  const code = generateCode();
  peer = new Peer(code);
  peer.on("open", (id) => {
    myPeerId = id;
    setStatus(`${id}`, "#6af");
    try { navigator.clipboard.writeText(id); } catch(e){}
  });
  peer.on("connection", (conn) => setupConn(conn));
  peer.on("error", (e) => setStatus("fout: "+e.type, "#f66"));
});

btnJoin.addEventListener("click", () => {
  codeInput.style.display = "inline-block";
  btnJoinConfirm.style.display = "inline-block";
  codeInput.focus();
});

btnJoinConfirm.addEventListener("click", doJoin);
codeInput.addEventListener("keydown", (e) => { if(e.key==="Enter") doJoin(); });

function doJoin() {
  const code = codeInput.value.trim().toUpperCase();
  if(!code) return;
  codeInput.style.display = "none";
  btnJoinConfirm.style.display = "none";
  if(peer) { peer.destroy(); peer=null; connections=[]; remotePlayers={}; }
  peer = new Peer();
  peer.on("open", (id) => {
    myPeerId = id;
    setStatus("verbinden...", "#fa0");
    const conn = peer.connect(code);
    setupConn(conn);
  });
  peer.on("error", (e) => setStatus("fout: "+e.type, "#f66"));
}

// ── GAME LOGIC ────────────────────────────────────────────────────────────────
function loadLevel() {
  const lvl = LEVELS[currentLevel];
  obstacles = lvl.obstacles.map(o=>({x:o[0],y:o[1],w:o[2],h:o[3]}));
  star = {x:lvl.star[0], y:lvl.star[1], size:10};
  dino = new Dino(lvl.player_start[0], lvl.player_start[1]);
}

function nextLevel() {
  currentLevel = (currentLevel + 1) % LEVELS.length;
  if(currentLevel === 0) {
    if(timerRunning) {
      timerCurrent = Date.now() - timerStart;
      timerRunning = false;
      if(highscore === null || timerCurrent < highscore) {
        highscore = timerCurrent;
        localStorage.setItem("platformer_highscore", highscore);
      }
    }
  } else if(currentLevel === 1 && !timerRunning) {
    timerStart = Date.now();
    timerRunning = true;
    timerCurrent = 0;
  }
  loadLevel();
}

window.addEventListener("keydown", e=>keys[e.key]=true);
window.addEventListener("keyup", e=>keys[e.key]=false);

// ── GAME LOOP met vaste 60fps ─────────────────────────────────────────────────
const TARGET_FPS = 60;
const FRAME_TIME = 1000 / TARGET_FPS;
let lastTime = 0;
let frameCount = 0;

function loop(timestamp) {
  requestAnimationFrame(loop);

  // Sla frames over als het te snel gaat
  if(timestamp - lastTime < FRAME_TIME) return;
  lastTime = timestamp;

  dino.vx = 0;
  if(keys["ArrowLeft"]) dino.vx = -2.5;
  if(keys["ArrowRight"]) dino.vx = 2.5;
  if(keys["ArrowUp"] && dino.canJump(obstacles)) dino.vy = -7;
  dino.update(obstacles);

  if(dino.x < star.x+star.size && dino.x+dino.w > star.x &&
     dino.y < star.y+star.size && dino.y+dino.h > star.y) nextLevel();

  frameCount++;
  broadcastPosition();
  if(frameCount % 30 === 0) cleanupRemotePlayers();

  if(timerRunning) timerCurrent = Date.now() - timerStart;

  // ── TEKEN ──
  ctx.clearRect(0,0,WIDTH,HEIGHT);

  ctx.fillStyle = "black";
  ctx.fillRect(0,GROUND_HEIGHT,WIDTH,HEIGHT-GROUND_HEIGHT);

  ctx.fillStyle = "#ccc";
  ctx.font = "bold 8px monospace";
  ctx.fillText(timerString(timerCurrent), 4, GROUND_HEIGHT + 12);
  if(highscore !== null) {
    ctx.fillStyle = "gold";
    ctx.fillText("best: " + timerString(highscore), 4, GROUND_HEIGHT + 26);
  }

  ctx.fillStyle = "gray";
  for(let o of obstacles) ctx.fillRect(o.x,o.y,o.w,o.h);

  ctx.fillStyle = "gold";
  ctx.beginPath();
  ctx.arc(star.x+5, star.y+5, 5, 0, Math.PI*2);
  ctx.fill();

  ctx.fillStyle = "blue";
  for(let id in remotePlayers) {
    const rp = remotePlayers[id];
    if(rp.level === currentLevel) ctx.fillRect(rp.x, rp.y, 10, 14);
  }

  dino.draw();
}

loadLevel();
requestAnimationFrame(loop);
