// ═══════════════════════════════════════════════════════
//  BLOCK LIST — add blocks here easily!
//  Format: { id, name, color, breakTime (ms), texture }
//  color is fallback if texture not loaded yet
// ═══════════════════════════════════════════════════════
const BLOCK_TYPES = [
  { id: "dirt",  name: "Dirt",  color: "#8B5E3C", breakTime: 500,  texture: "dirt.png"  },
  { id: "grass", name: "Grass", color: "#4CAF50", breakTime: 500,  texture: "grass.png" },
  { id: "stone", name: "Stone", color: "#9E9E9E", breakTime: 1200, texture: "stone.png" },
  { id: "log",   name: "Log",   color: "#795548", breakTime: 800,  texture: "log.png"   },
];

// One block drops
const ONE_BLOCK_DROPS = [
  { id: "dirt",  weight: 10 },
  { id: "grass", weight: 8  },
  { id: "stone", weight: 8  },
  { id: "log",   weight: 6  },
];

// Preload textures
const TEXTURES = {};
for(const bt of BLOCK_TYPES) {
  const img = new Image();
  img.src = bt.texture;
  TEXTURES[bt.id] = img;
}
const MYSTERY_TEX = new Image();
MYSTERY_TEX.src = "mystery.png";

// ═══════════════════════════════════════════════════════
//  CONSTANTEN
// ═══════════════════════════════════════════════════════
const BLOCK_SIZE  = 16;
const WORLD_W     = 25;
const WORLD_H     = 11;
const HOTBAR_SLOTS = 8;
const CANVAS_W    = 200;
const CANVAS_H    = 200;
const HOTBAR_H    = 24;
const MPBAR_H     = 20;
const VIEW_H      = CANVAS_H - HOTBAR_H; // 176px = 11 * 16
const FLOOR_Y     = VIEW_H; // bottom of play area = top of hotbar
const GRAVITY     = 0.35;
const JUMP_FORCE  = -5.5;
const MOVE_SPEED  = 1.5;
const ONE_BLOCK_X = Math.floor(WORLD_W / 2);
const ONE_BLOCK_Y = Math.floor(WORLD_H / 2);

const canvas = document.getElementById("game");
const ctx    = canvas.getContext("2d");

// ═══════════════════════════════════════════════════════
//  WORLD — load from localStorage or start fresh
// ═══════════════════════════════════════════════════════
function loadWorld() {
  try {
    const saved = localStorage.getItem("onesquare_world");
    if(saved) return JSON.parse(saved);
  } catch(e) {}
  return Array.from({length: WORLD_H}, () => Array(WORLD_W).fill(null));
}

function saveWorld() {
  try { localStorage.setItem("onesquare_world", JSON.stringify(world)); } catch(e) {}
}

function resetWorld() {
  world = Array.from({length: WORLD_H}, () => Array(WORLD_W).fill(null));
  hotbar = Array(HOTBAR_SLOTS).fill(null);
  saveWorld();
  spawnPlayer();
  broadcastWorld();
}

let world = loadWorld();

// ═══════════════════════════════════════════════════════
//  HOTBAR
// ═══════════════════════════════════════════════════════
let hotbar      = Array(HOTBAR_SLOTS).fill(null);
let selectedSlot = 0;

function addToHotbar(id) {
  for(let i = 0; i < HOTBAR_SLOTS; i++) {
    if(hotbar[i] && hotbar[i].id === id) { hotbar[i].count++; return; }
  }
  for(let i = 0; i < HOTBAR_SLOTS; i++) {
    if(!hotbar[i]) { hotbar[i] = {id, count:1}; return; }
  }
}

function removeFromHotbar(slot) {
  if(!hotbar[slot]) return false;
  hotbar[slot].count--;
  if(hotbar[slot].count <= 0) hotbar[slot] = null;
  return true;
}

function getBlockType(id) {
  return BLOCK_TYPES.find(b => b.id === id) || null;
}

function getRandomDrop() {
  const total = ONE_BLOCK_DROPS.reduce((s,d) => s+d.weight, 0);
  let r = Math.random() * total;
  for(const d of ONE_BLOCK_DROPS) { r -= d.weight; if(r <= 0) return d.id; }
  return ONE_BLOCK_DROPS[0].id;
}

// ═══════════════════════════════════════════════════════
//  SPELER
// ═══════════════════════════════════════════════════════
class Player {
  constructor(x, y, color="red") {
    this.px = x * BLOCK_SIZE;
    this.py = y * BLOCK_SIZE;
    this.w  = 10;
    this.h  = 14;
    this.vx = 0;
    this.vy = 0;
    this.onGround = false;
    this.color = color;
  }

  isSolid(bx, by) {
    if(bx < 0 || bx >= WORLD_W) return true;
    if(by >= WORLD_H) return true;
    if(by < 0) return false;
    if(bx === ONE_BLOCK_X && by === ONE_BLOCK_Y) return true;
    return world[by][bx] !== null;
  }

  update(keys) {
    this.vx = 0;
    if(keys["ArrowLeft"])  this.vx = -MOVE_SPEED;
    if(keys["ArrowRight"]) this.vx =  MOVE_SPEED;
    if((keys["ArrowUp"] || keys[" "]) && this.onGround) {
      this.vy = JUMP_FORCE;
      this.onGround = false;
    }

    // Horizontal movement
    this.px += this.vx;
    const left  = Math.floor(this.px / BLOCK_SIZE);
    const right = Math.floor((this.px + this.w - 0.01) / BLOCK_SIZE);
    const top   = Math.floor(this.py / BLOCK_SIZE);
    const bot   = Math.floor((this.py + this.h - 0.01) / BLOCK_SIZE);
    if(this.vx > 0 && (this.isSolid(right, top) || this.isSolid(right, bot))) {
      this.px = right * BLOCK_SIZE - this.w - 0.01;
    }
    if(this.vx < 0 && (this.isSolid(left, top) || this.isSolid(left, bot))) {
      this.px = (left + 1) * BLOCK_SIZE;
    }

    // Gravity
    this.vy += GRAVITY;
    this.py += this.vy;
    const left2  = Math.floor(this.px / BLOCK_SIZE);
    const right2 = Math.floor((this.px + this.w - 0.01) / BLOCK_SIZE);
    const top2   = Math.floor(this.py / BLOCK_SIZE);
    const bot2   = Math.floor((this.py + this.h - 0.01) / BLOCK_SIZE);
    if(this.vy > 0 && (this.isSolid(left2, bot2) || this.isSolid(right2, bot2))) {
      this.py = bot2 * BLOCK_SIZE - this.h;
      this.vy = 0;
      this.onGround = true;
    } else if(this.vy < 0 || (!this.isSolid(left2, bot2+1) && !this.isSolid(right2, bot2+1))) {
      this.onGround = false;
    }
    if(this.vy < 0 && (this.isSolid(left2, top2) || this.isSolid(right2, top2))) {
      this.py = (top2 + 1) * BLOCK_SIZE;
      this.vy = 0;
    }

    // Floor = top of hotbar
    if(this.py + this.h >= FLOOR_Y) {
      this.py = FLOOR_Y - this.h;
      this.vy = 0;
      this.onGround = true;
    }

    // Respawn if fallen off top
    if(this.py < -this.h * 2) {
      this.py = 0;
      this.vy = 0;
    }

    // Camera follows player
    camX = this.px - CANVAS_W / 2 + this.w / 2;
    camX = Math.max(0, Math.min(WORLD_W * BLOCK_SIZE - CANVAS_W, camX));
  }

  draw() {
    const sx = Math.round(this.px - camX);
    const sy = Math.round(this.py - camY);
    ctx.fillStyle = this.color;
    ctx.fillRect(sx, sy, this.w, this.h);
  }
}

// Camera
let camX = 0;
const camY = 0;

function spawnPlayer() {
  player.px = ONE_BLOCK_X * BLOCK_SIZE;
  player.py = (ONE_BLOCK_Y - 1) * BLOCK_SIZE;
  player.vx = 0;
  player.vy = 0;
}

let player = new Player(ONE_BLOCK_X, ONE_BLOCK_Y - 1);

// ═══════════════════════════════════════════════════════
//  BLOK BREKEN
// ═══════════════════════════════════════════════════════
let breaking = null; // { bx, by, startTime, duration }

function worldToScreen(bx, by) {
  return {
    sx: bx * BLOCK_SIZE - camX,
    sy: by * BLOCK_SIZE - camY
  };
}

function screenToWorld(sx, sy) {
  return {
    bx: Math.floor((sx + camX) / BLOCK_SIZE),
    by: Math.floor((sy + camY) / BLOCK_SIZE)
  };
}

canvas.addEventListener("mousedown", (e) => {
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left;
  const my = e.clientY - rect.top;

  // Hotbar click
  const slotW = CANVAS_W / HOTBAR_SLOTS;
  if(my >= VIEW_H) {
    const slot = Math.floor(mx / slotW);
    if(slot >= 0 && slot < HOTBAR_SLOTS) selectedSlot = slot;
    return;
  }

  const {bx, by} = screenToWorld(mx, my);

  if(e.button === 2) {
    e.preventDefault();
    placeBlock(bx, by);
  } else if(e.button === 0) {
    startBreaking(bx, by);
  }
});

canvas.addEventListener("mouseup", (e) => {
  if(e.button === 0) breaking = null;
});

canvas.addEventListener("contextmenu", e => e.preventDefault());

function startBreaking(bx, by) {
  if(bx < 0 || bx >= WORLD_W || by < 0 || by >= WORLD_H) return;

  // One block
  if(bx === ONE_BLOCK_X && by === ONE_BLOCK_Y) {
    breaking = { bx, by, startTime: Date.now(), duration: 800, isOneBlock: true };
    return;
  }

  if(world[by][bx] === null) return;
  const bt = getBlockType(world[by][bx]);
  if(!bt) return;
  breaking = { bx, by, startTime: Date.now(), duration: bt.breakTime, isOneBlock: false };
}

function placeBlock(bx, by) {
  if(bx < 0 || bx >= WORLD_W || by < 0 || by >= WORLD_H) return;
  if(bx === ONE_BLOCK_X && by === ONE_BLOCK_Y) return;
  if(world[by][bx] !== null) return;

  // Check player is not standing in this block
  const px1 = Math.floor(player.px / BLOCK_SIZE);
  const px2 = Math.floor((player.px + player.w - 0.01) / BLOCK_SIZE);
  const py1 = Math.floor(player.py / BLOCK_SIZE);
  const py2 = Math.floor((player.py + player.h - 0.01) / BLOCK_SIZE);
  if(bx >= px1 && bx <= px2 && by >= py1 && by <= py2) return;

  const slot = hotbar[selectedSlot];
  if(!slot) return;

  world[by][bx] = slot.id;
  removeFromHotbar(selectedSlot);
  broadcastWorld();
}

// ═══════════════════════════════════════════════════════
//  MULTIPLAYER
// ═══════════════════════════════════════════════════════
let peer = null;
let connections = [];
let remotePlayers = {};
const TIMEOUT_MS = 10000;

const statusEl       = document.getElementById("mp-status");
const codeInput      = document.getElementById("code-input");
const btnHost        = document.getElementById("btn-host");
const btnJoin        = document.getElementById("btn-join");
const btnJoinConfirm = document.getElementById("btn-join-confirm");

const btnReset       = document.getElementById("btn-reset");
btnReset.addEventListener("click", () => resetWorld());

function setStatus(msg, color="#aaa") {
  statusEl.textContent = msg;
  statusEl.style.color = color;
}

function generateCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for(let i=0;i<4;i++) code += chars[Math.floor(Math.random()*chars.length)];
  return code;
}

let lastSentX = -1, lastSentY = -1, heartbeat = 0;

function broadcastPos() {
  if(!connections.length) return;
  heartbeat++;
  const moved = Math.round(player.px) !== lastSentX || Math.round(player.py) !== lastSentY;
  if(!moved && heartbeat < 30) return;
  heartbeat = 0;
  lastSentX = Math.round(player.px);
  lastSentY = Math.round(player.py);
  send({ type:"pos", px: lastSentX, py: lastSentY });
}

function broadcastWorld() {
  saveWorld();
  if(!connections.length) return;
  send({ type:"world", world });
}

function send(data) {
  for(const conn of connections) { if(conn.open) conn.send(data); }
}

function handleData(peerId, data) {
  if(data.type === "pos") {
    remotePlayers[peerId] = { px: data.px, py: data.py, lastSeen: Date.now() };
  } else if(data.type === "world") {
    world = data.world;
  } else if(data.type === "sync_request") {
    // Nieuwe speler vraagt wereld op
    const conn = connections.find(c => c.peer === peerId);
    if(conn && conn.open) conn.send({ type:"world", world });
  }
}

function cleanupRemote() {
  const now = Date.now();
  for(let id in remotePlayers) {
    if(now - remotePlayers[id].lastSeen > TIMEOUT_MS) delete remotePlayers[id];
  }
}

function setupConn(conn, isJoiner=false) {
  connections.push(conn);
  conn.on("data", d => handleData(conn.peer, d));
  conn.on("close", () => {
    connections = connections.filter(c => c !== conn);
    delete remotePlayers[conn.peer];
    setStatus(connections.length ? `${connections.length} connected` : "offline",
              connections.length ? "#6f6" : "#aaa");
  });
  conn.on("error", () => {
    connections = connections.filter(c => c !== conn);
    delete remotePlayers[conn.peer];
    setStatus(connections.length ? `${connections.length} connected` : "offline",
              connections.length ? "#6f6" : "#aaa");
  });
  conn.on("open", () => {
    setStatus(`${connections.length} connected`, "#6f6");
    if(isJoiner) conn.send({ type:"sync_request" });
  });
}

btnHost.addEventListener("click", () => {
  if(peer) { peer.destroy(); peer=null; connections=[]; remotePlayers={}; }
  const code = generateCode();
  peer = new Peer(code);
  peer.on("open", id => {
    setStatus(`${id}`, "#6af");
    try { navigator.clipboard.writeText(id); } catch(e) {}
  });
  peer.on("connection", conn => setupConn(conn, false));
  peer.on("error", e => setStatus("error: "+e.type, "#f66"));
});

btnJoin.addEventListener("click", () => {
  codeInput.style.display = "inline-block";
  btnJoinConfirm.style.display = "inline-block";
  codeInput.focus();
});

btnJoinConfirm.addEventListener("click", doJoin);
codeInput.addEventListener("keydown", e => { if(e.key==="Enter") doJoin(); });

function doJoin() {
  const code = codeInput.value.trim().toUpperCase();
  if(!code) return;
  codeInput.style.display = "none";
  btnJoinConfirm.style.display = "none";
  if(peer) { peer.destroy(); peer=null; connections=[]; remotePlayers={}; }
  peer = new Peer();
  peer.on("open", () => {
    setStatus("connecting...", "#fa0");
    const conn = peer.connect(code);
    setupConn(conn, true);
  });
  peer.on("error", e => setStatus("error: "+e.type, "#f66"));
}

// ═══════════════════════════════════════════════════════
//  TEKENEN
// ═══════════════════════════════════════════════════════
function drawWorld() {
  // Achtergrond (lucht)
  ctx.fillStyle = "#87CEEB";
  ctx.fillRect(0, 0, CANVAS_W, VIEW_H);

  // Blokken
  for(let by = 0; by < WORLD_H; by++) {
    for(let bx = 0; bx < WORLD_W; bx++) {
      const {sx, sy} = worldToScreen(bx, by);
      if(sx + BLOCK_SIZE < 0 || sx > CANVAS_W) continue;

      // One block
      if(bx === ONE_BLOCK_X && by === ONE_BLOCK_Y) {
        if(MYSTERY_TEX.complete && MYSTERY_TEX.naturalWidth > 0) {
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(MYSTERY_TEX, sx, sy, BLOCK_SIZE, BLOCK_SIZE);
        } else {
          ctx.fillStyle = "#7B1FA2";
          ctx.fillRect(sx, sy, BLOCK_SIZE, BLOCK_SIZE);
        }
        if(breaking && breaking.bx === bx && breaking.by === by) {
          const prog = Math.min(1, (Date.now() - breaking.startTime) / breaking.duration);
          ctx.fillStyle = `rgba(0,0,0,${prog * 0.7})`;
          ctx.fillRect(sx, sy, BLOCK_SIZE, BLOCK_SIZE);
        }
        continue;
      }

      const id = world[by][bx];
      if(!id) continue;
      const bt = getBlockType(id);
      if(!bt) continue;

      const tex = TEXTURES[id];
      if(tex && tex.complete && tex.naturalWidth > 0) {
        ctx.imageSmoothingEnabled = false;
        ctx.drawImage(tex, sx, sy, BLOCK_SIZE, BLOCK_SIZE);
      } else {
        ctx.fillStyle = bt.color;
        ctx.fillRect(sx, sy, BLOCK_SIZE, BLOCK_SIZE);
      }

      // Break animation
      if(breaking && breaking.bx === bx && breaking.by === by) {
        const prog = Math.min(1, (Date.now() - breaking.startTime) / breaking.duration);
        ctx.fillStyle = `rgba(0,0,0,${prog * 0.7})`;
        ctx.fillRect(sx, sy, BLOCK_SIZE, BLOCK_SIZE);
        const cracks = Math.floor(prog * 4);
        ctx.strokeStyle = `rgba(0,0,0,${prog})`;
        ctx.lineWidth = 1;
        if(cracks >= 1) { ctx.beginPath(); ctx.moveTo(sx+4,sy+4); ctx.lineTo(sx+8,sy+10); ctx.stroke(); }
        if(cracks >= 2) { ctx.beginPath(); ctx.moveTo(sx+8,sy+2); ctx.lineTo(sx+13,sy+8); ctx.stroke(); }
        if(cracks >= 3) { ctx.beginPath(); ctx.moveTo(sx+3,sy+10); ctx.lineTo(sx+9,sy+14); ctx.stroke(); }
        if(cracks >= 4) { ctx.beginPath(); ctx.moveTo(sx+11,sy+5); ctx.lineTo(sx+15,sy+12); ctx.stroke(); }
        ctx.lineWidth = 1;
      }
    }
  }
}

function drawHotbar() {
  const slotW = CANVAS_W / HOTBAR_SLOTS;
  const barY  = VIEW_H;

  ctx.fillStyle = "#333";
  ctx.fillRect(0, barY, CANVAS_W, HOTBAR_H);

  for(let i = 0; i < HOTBAR_SLOTS; i++) {
    const sx = i * slotW;
    const sy = barY + 2;
    const sw = slotW - 2;
    const sh = HOTBAR_H - 4;

    // Achtergrond slot
    ctx.fillStyle = i === selectedSlot ? "#666" : "#444";
    ctx.fillRect(sx+1, sy, sw, sh);
    ctx.strokeStyle = i === selectedSlot ? "#fff" : "#555";
    ctx.strokeRect(sx+1.5, sy+0.5, sw-1, sh-1);

    const slot = hotbar[i];
    if(slot) {
      const bt = getBlockType(slot.id);
      if(bt) {
        const tex = TEXTURES[slot.id];
        if(tex && tex.complete && tex.naturalWidth > 0) {
          ctx.imageSmoothingEnabled = false;
          ctx.drawImage(tex, sx+3, sy+2, sw-4, sh-4);
        } else {
          ctx.fillStyle = bt.color;
          ctx.fillRect(sx+3, sy+2, sw-4, sh-4);
        }
        ctx.fillStyle = "white";
        ctx.font = "5px monospace";
        ctx.fillText(slot.count, sx+2, barY+HOTBAR_H-4);
      }
    }
  }
}

function drawRemotePlayers() {
  ctx.fillStyle = "blue";
  for(let id in remotePlayers) {
    const rp = remotePlayers[id];
    const sx = Math.round(rp.px - camX);
    const sy = Math.round(rp.py - camY);
    ctx.fillRect(sx, sy, 10, 14);
  }
}

// ═══════════════════════════════════════════════════════
//  INPUT
// ═══════════════════════════════════════════════════════
const keys = {};
window.addEventListener("keydown", e => {
  keys[e.key] = true;
  // Hotbar selectie via 1-8
  if(e.key >= "1" && e.key <= "8") selectedSlot = parseInt(e.key) - 1;
});
window.addEventListener("keyup", e => keys[e.key] = false);

// Scroll voor hotbar
canvas.addEventListener("wheel", e => {
  e.preventDefault();
  selectedSlot = (selectedSlot + (e.deltaY > 0 ? 1 : -1) + HOTBAR_SLOTS) % HOTBAR_SLOTS;
}, { passive: false });

// ═══════════════════════════════════════════════════════
//  GAME LOOP
// ═══════════════════════════════════════════════════════
const TARGET_FPS  = 60;
const FRAME_TIME  = 1000 / TARGET_FPS;
let lastTime = 0;
let frameCount = 0;

function loop(timestamp) {
  requestAnimationFrame(loop);
  if(timestamp - lastTime < FRAME_TIME) return;
  lastTime = timestamp;

  player.update(keys);

  // Breek logica
  if(breaking) {
    const elapsed = Date.now() - breaking.startTime;
    if(elapsed >= breaking.duration) {
      const {bx, by} = breaking;
      if(breaking.isOneBlock) {
        // One block geeft drop + blijft
        addToHotbar(getRandomDrop());
        broadcastWorld();
      } else {
        // Normaal blok breken
        const id = world[by][bx];
        if(id) {
          addToHotbar(id);
          world[by][bx] = null;
          broadcastWorld();
        }
      }
      breaking = null;
    }
  }

  frameCount++;
  broadcastPos();
  if(frameCount % 30 === 0) cleanupRemote();

  // Teken
  ctx.clearRect(0, 0, CANVAS_W, CANVAS_H);
  drawWorld();
  drawRemotePlayers();
  player.draw();
  drawHotbar();
}

requestAnimationFrame(loop);

// Prevent mp-bar clicks from triggering canvas events
document.getElementById("mp-bar").addEventListener("mousedown", e => e.stopPropagation());
document.getElementById("mp-bar").addEventListener("click", e => e.stopPropagation());
