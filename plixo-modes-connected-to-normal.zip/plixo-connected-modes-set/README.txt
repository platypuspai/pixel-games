PLIXO ARCADE — CONNECTED MODES SET

Upload these five HTML files into the SAME website folder:
- index.html
- mini-browser-platformer-modes.html
- mini-browser-platformer.html
- mini-spikes-platformer-modes.html
- mini-spikes-platformer.html

Connection flow:
index.html -> matching Modes page -> matching normal game HTML.
The Modes pages use the exact normal game filenames (no -race3 suffix).
Each game's mode is passed using ?mode=single, ?mode=multiplayer, or ?mode=race.

After uploading, refresh the website with Ctrl+F5.
